# NK57 Monospace

<img src="https://i.ibb.co/7X4k1CT/Screenshot-Keep-notes-20190528-113032.png" alt="Screenshot">

## Instructions:
- Install
- Reboot
- Enjoy!!

## Infos:
- Licence: GPL3

### v1
- Initial release

### Source
https://github.com/arul20be/NK57-Monospace
